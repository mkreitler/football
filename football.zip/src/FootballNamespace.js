// Define a namespace for PhysWiz.

var fb = {};
var gameWidth = 768;
var gameHeight = 1024;
