// "Sprites" layers render sprites into a scene. Each sprite receives a z-order, with 0
// representing the foreground and higher numbers moving further into the background.
// Layers are responsible for calling 'update' and 'draw' for the sprites in their view.