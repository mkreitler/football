// Indexers iterate through a list of indeces.

joe.Indexer = new joe.ClassEx({
},
{
  sequence: [],
  
});